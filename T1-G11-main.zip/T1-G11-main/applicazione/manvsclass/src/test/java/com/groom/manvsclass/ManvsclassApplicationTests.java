package com.groom.manvsclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManvsclassApplicationTests {

	@Test
	void contextLoads() {
	}

}
